## README.md for cluster3

This is the module for creating/changing/destroying resources for cluster1

**Commands**:

1. 'terraform plan' - Returns a PLAN of what would be created/changed/destroyed
2. 'terraform apply' - Applies changes created/changed/destroyed
3. 'terraform destroy' - Destroys terraform resources
